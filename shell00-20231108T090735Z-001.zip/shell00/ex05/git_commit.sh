#!/bin/bash
#
set -e
git log -5 --format=%H
